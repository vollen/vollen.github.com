package cn.bjguanghe.x.android.simplesdk.base.ui;

/**
 * Created by mob on 15/11/2.
 */
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class TopLineView extends View {

    private int mRadius = 40;
    private int mColor = 0;

    private RectF mRect = new RectF();
    private Paint mPaint = new Paint();

    public TopLineView(Context context) {
        super(context);
    }

    public void setRadius(int cornerRadius) {
        this.mRadius = cornerRadius;
    }

    public void setColor(int color) {
        this.mColor = color;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        this.mPaint.setAntiAlias(true);
        this.mPaint.setColor(this.mColor);

        int width = getWidth();

        this.mRect.left = 0.0F;
        this.mRect.top = 0.0F;
        this.mRect.right = this.mRadius*2;
        this.mRect.bottom = this.mRadius*2;
        canvas.drawArc(this.mRect, 180.0F, 180.0F, false, this.mPaint);

        this.mRect.left = width - this.mRadius*2;
        this.mRect.top = 0.0F;
        this.mRect.right = width;
        this.mRect.bottom = this.mRadius*2;
        canvas.drawArc(this.mRect, 180.0F, 180.0F, false, this.mPaint);

        canvas.drawRect(this.mRadius + 1, 0.0F, width - this.mRadius - 1, this.mRadius, this.mPaint);
    }
}

