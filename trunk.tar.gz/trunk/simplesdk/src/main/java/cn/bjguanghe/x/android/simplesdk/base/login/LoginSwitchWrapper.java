package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;
import cn.bjguanghe.x.android.simplesdk.base.compatible.CompatibleUtil;
import cn.bjguanghe.x.android.simplesdk.base.misc.GradientDrawableCreator;

/**
 * Created by mob on 15/11/7.
 */
public class LoginSwitchWrapper extends LoginViewWrapper {

    private final TextView textView;
    private final Button button;

    public LoginSwitchWrapper(Context hostContext) {
        super(hostContext);

        FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = 17;
        params.width = DrawableUtil.s_screenWidth;
        params.height = DrawableUtil.s_screenHeight;
        rootView.setLayoutParams(params);

        //content
        LinearLayout contentLayout = new LinearLayout(hostContext);
        LinearLayout.LayoutParams contentParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        contentParams.gravity = 49;
        contentParams.height = DrawableUtil.dp2px(60.0F);
        contentParams.topMargin = DrawableUtil.dp2px(20.0F);
        contentParams.leftMargin = DrawableUtil.dp2px(20.0F);
        contentParams.rightMargin = DrawableUtil.dp2px(20.0F);
        contentLayout.setLayoutParams(contentParams);
        contentLayout.setOrientation(LinearLayout.HORIZONTAL);
        contentLayout.setGravity(17);
        CompatibleUtil.setBackgroundDrawable(contentLayout, GradientDrawableCreator.getDrawable(5, -1090519040));
        rootView.addView(contentLayout);

        //text view
        textView = createTextView(18, Color.RED);
        LinearLayout.LayoutParams textParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textParams.weight = 1.0F;
        textParams.leftMargin = DrawableUtil.dp2px(20.0F);
        textView.setLayoutParams(textParams);
        textView.setText("测试一下");
        contentLayout.addView(textView);

        //button view
        button = createButton(18, Color.RED);
        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        buttonParams.width = DrawableUtil.dp2px(90.0F);
        buttonParams.height = DrawableUtil.dp2px(40.0F);
        buttonParams.rightMargin = DrawableUtil.dp2px(20.0F);
        button.setLayoutParams(buttonParams);
        CompatibleUtil.setBackgroundDrawable(button, GradientDrawableCreator.getDualStateDrawable(5, -37888, -2071543));
        button.setText("切换账号");
        contentLayout.addView(button);

        rootView.setVisibility(View.GONE);
    }
}
