package cn.bjguanghe.x.android.simplesdk.exception;

/**
 * Created by leng on 16-1-8.
 */
public class NetInvalidException extends Exception
{
    public NetInvalidException(){
        super("网络连接不可用 请检查网络设置");
    }
}
