package cn.bjguanghe.x.android.simplesdk.base.net;

import org.xutils.http.RequestParams;

/**
 * Created by leng on 16-1-6.
*/
public class DefaultParams extends RequestParams {
    public DefaultParams(String path){
        super(path);
        setAsJsonContent(true);
        setUseCookie(false);
    }
}
