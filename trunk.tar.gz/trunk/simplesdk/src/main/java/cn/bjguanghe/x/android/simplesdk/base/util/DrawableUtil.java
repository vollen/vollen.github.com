package cn.bjguanghe.x.android.simplesdk.base.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.DisplayMetrics;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by mob on 15/11/2.
 */
public class DrawableUtil {
    public static float s_density = 1.0F;
    public static int s_densityDpi = DisplayMetrics.DENSITY_DEFAULT;
    public static int s_screenWidth = 0;
    public static int s_screenHeight = 0;

    private static Context s_ctx;

    public static void init(Context ctx) {
        if(ctx == null) {
            return;
        }
        s_ctx = ctx;
        DisplayMetrics displayMetrics = ctx.getResources().getDisplayMetrics();
        s_density = displayMetrics.density;
        s_densityDpi = displayMetrics.densityDpi;
        s_screenWidth = displayMetrics.widthPixels;
        s_screenHeight = displayMetrics.heightPixels;
    }

    //根据dp计算像素值
    public static int dp2px(float dp) {
        return (int)(0.5F + s_density * dp);
    }

    //等比缩放后的宽度
    public static float uniformScaleWidth(int oriWidth, int oriHeight, float scaledHeight) {
        return (float)oriWidth / (float)oriHeight * scaledHeight;
    }

    //等比缩放后的高度
    public static float uniformScaleHeight(int oriWidth, int oriHeight, float scaledWidth) {
        return (float)oriHeight / (float)oriWidth * scaledWidth;
    }

    //计算缩放前的像素值(这样可以保证某些表现在不同手机上是一样的)
    public static float pixel(int scaledPixel) {
        return scaledPixel * (160.0F / s_densityDpi);
    }

    public static Drawable getDualStateDrawable(String imgNameEnabled, String imgNamePressed) {
        return getDualStateDrawable(getDrawableByName(imgNameEnabled), getDrawableByName(imgNamePressed));
    }

    public static Drawable getDualStateDrawable(String imgNameEnabled, String imgNameState, int state) {
        return getDualStateDrawable(getDrawableByName(imgNameEnabled), getDrawableByName(imgNameState), state);
    }

    public static Drawable getDualStateDrawable(Drawable drawableEnabled, Drawable drawableState, int state) {
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{state}, drawableState);
        stateListDrawable.addState(new int[]{android.R.attr.state_enabled}, drawableEnabled);
        return stateListDrawable;
    }

    public static Drawable getDualStateDrawable(Drawable drawableEnabled, Drawable drawablePressed) {
        StateListDrawable resultDrawable = new StateListDrawable();
        resultDrawable.addState(new int[]{android.R.attr.state_pressed}, drawablePressed);
        resultDrawable.addState(new int[]{android.R.attr.state_enabled}, drawableEnabled);
        return resultDrawable;
    }

    public static Drawable getDrawableByName(String imgName) {
        //从files目录
        Drawable drawable = getDrawableByPath("/data/data/" + s_ctx.getPackageName() + "/files/" + "base/res/" + imgName);

        //没有找到则去assets目录
        if(drawable == null) {
            drawable = getDrawableByPathFromAssets("base/res/" + imgName);
        }

        //都没有找到
        if(drawable == null) {
            // TODO: 15/11/4 找一个比较合适的颜色
            drawable = new ColorDrawable(Color.BLUE);

            //出错了 执行删除base文件夹 以便能够进行恢复操作
            FileUtil.deleteFile(FileUtil.getFile(s_ctx, "base"));
        }
        return drawable;
    }

    public static Drawable getDrawableByPathFromAssets(String imgPath) {
        try {
            return getDrawableByStream(s_ctx.getResources().getAssets().open(imgPath));
        }catch (IOException e){}
        return null;
    }


    public static Drawable getDrawableByPath(String imgPath) {
        try {
            FileInputStream fileInputStream = new FileInputStream(imgPath);
            return getDrawableByStream(fileInputStream);
        } catch(FileNotFoundException e) {}
        return null;
    }

    public static Drawable getDrawableByStream(InputStream imgFileStream) {
        Rect imgRect = new Rect();
        Bitmap bitmap = BitmapFactory.decodeStream(imgFileStream, imgRect, null);
        byte[] chunkBytes = bitmap.getNinePatchChunk();
        if(chunkBytes == null) {
            return new BitmapDrawable(s_ctx.getResources(), bitmap);
        }
        return new NinePatchDrawable(s_ctx.getResources(), bitmap, chunkBytes, imgRect, null);
    }

    //获取对drawable进行等比缩放的Params
    public static LinearLayout.LayoutParams getLinerLayoutParamsUniformScaleByHeight(Drawable targetDrawable, float scaledHeight) {
        int width = 0;
        int height = 0;
        Drawable drawable = targetDrawable;
        if(targetDrawable instanceof StateListDrawable) {
            drawable = targetDrawable.getCurrent();
        }
        if(drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap();
            height = dp2px(scaledHeight);
            width = dp2px(uniformScaleWidth(bitmap.getWidth(), bitmap.getHeight(), scaledHeight));
        }
        return new LinearLayout.LayoutParams(width, height);
    }

    public static FrameLayout.LayoutParams getFrameLayoutParamsUniformScaleByWidth(Drawable targetDrawable, float scaledWidth) {
        int width = 0;
        int height = 0;
        Drawable drawable = targetDrawable;
        if(targetDrawable instanceof StateListDrawable) {
            drawable = targetDrawable.getCurrent();
        }
        if(drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap();
            width = dp2px(scaledWidth);
            height = dp2px(uniformScaleHeight(bitmap.getWidth(), bitmap.getHeight(), scaledWidth));
        }
        return new FrameLayout.LayoutParams(width, height);
    }
}
