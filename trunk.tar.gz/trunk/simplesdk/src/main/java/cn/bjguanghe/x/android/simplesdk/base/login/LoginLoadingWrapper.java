package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;
import cn.bjguanghe.x.android.simplesdk.base.compatible.CompatibleUtil;

/**
 * Created by mob on 15/11/6.
 */
public class LoginLoadingWrapper extends LoginViewWrapper{

    private final ViewGroup container;
    private final ProgressBar waitingBar;
    private final TextView textView;

    public LoginLoadingWrapper(Context hostContext) {
        super(hostContext);

        FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        if(DrawableUtil.s_screenWidth > DrawableUtil.s_screenHeight) {
            params.width = DrawableUtil.dp2px(LoginFuncViewWrapper.LandscapeWidth);
            params.height = DrawableUtil.dp2px(LoginFuncViewWrapper.LandscapeHeight);
        } else {
            params.width = DrawableUtil.dp2px(LoginFuncViewWrapper.PortraitWidth);
            params.width = DrawableUtil.dp2px(LoginFuncViewWrapper.PortraitHeight);
        }
        rootView.setLayoutParams(params);

        //container
        container = new FrameLayout(hostContext);
        FrameLayout.LayoutParams containerParams =
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        containerParams.gravity = Gravity.CENTER;
        containerParams.width = DrawableUtil.dp2px(150.0F);
        containerParams.height = DrawableUtil.dp2px(150.0F);
        container.setLayoutParams(containerParams);
        GradientDrawable bgDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-1090519040, -1090519040});
        bgDrawable.setCornerRadius(DrawableUtil.dp2px(5.0F));
        CompatibleUtil.setBackgroundDrawable(container, bgDrawable);

        rootView.addView(container);

        //waiting progress bar
        waitingBar = new ProgressBar(hostContext);
        FrameLayout.LayoutParams waitingParams =
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        waitingParams.gravity = Gravity.CENTER;
        waitingParams.width = DrawableUtil.dp2px(80.0F);
        waitingParams.height = DrawableUtil.dp2px(80.0F);
        waitingBar.setLayoutParams(waitingParams);
        waitingBar.setIndeterminate(true);
        waitingBar.setIndeterminateDrawable(DrawableUtil.getDrawableByName("base_login_loading_circle.png"));
        container.addView(waitingBar);

        //logo
        Drawable loadingTextDrawable = DrawableUtil.getDrawableByName("base_login_loading_text.png");
        View logoView = new TextView(hostContext);
        FrameLayout.LayoutParams logoParams = DrawableUtil.getFrameLayoutParamsUniformScaleByWidth(loadingTextDrawable, 50.0F);
        logoParams.gravity = Gravity.CENTER;
        logoView.setLayoutParams(logoParams);
        CompatibleUtil.setBackgroundDrawable(logoView, loadingTextDrawable);

        container.addView(logoView);

        //text view
        textView = new TextView(hostContext);
        FrameLayout.LayoutParams textParams =
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        // TODO: 15/11/6 81--->确定是哪个值
        textParams.gravity = 81;
        textView.setPadding(0, 0, 0, 0);
        textView.setLayoutParams(textParams);
        textView.setTextSize(0, DrawableUtil.dp2px(14.0F));
        // TODO: 15/11/6 决定一个合适的颜色
        textView.setTextColor(Color.RED);
        container.addView(textView);

        container.setPadding(0, 0, 0, DrawableUtil.dp2px(15.0F));

        rootView.setVisibility(View.GONE);
    }

    public void hide() {
        rootView.setVisibility(View.GONE);
        waitingBar.clearAnimation();
    }

    public void show(String text) {
        if(text == null) {
            text = "";
        }
        textView.setText(text);

        if(rootView.getVisibility() != View.VISIBLE) {
            RotateAnimation animation = new RotateAnimation(0.0F, 360.0F, 1, 0.5F, 1, 0.5F);
            animation.setRepeatCount(Animation.INFINITE);
            animation.setDuration(1000L);
            animation.setInterpolator(new LinearInterpolator());
            waitingBar.clearAnimation();
            waitingBar.startAnimation(animation);
            rootView.setVisibility(View.VISIBLE);
        }
    }
}
