package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.view.View;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;

/**
 * Created by mob on 15/11/5.
 */
public class LoginLoginWrapper extends LoginFuncViewWrapper {

    public LoginLoginWrapper(Context hostContext) {
        super(hostContext);
        DrawableUtil.init(hostContext);
        //登录界面没有back button
        this.imageButtonBack.setVisibility(View.GONE);
        setTitle("base_login_title_login.png");
    }
}
