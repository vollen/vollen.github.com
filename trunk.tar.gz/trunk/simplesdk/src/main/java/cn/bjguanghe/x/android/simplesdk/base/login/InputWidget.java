package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import cn.bjguanghe.x.android.simplesdk.base.compatible.CompatibleUtil;
import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;

/**
 * Created by leng on 16-1-9.
 */
public class InputWidget {
    public static int a = 50;
    public static int b = 30;
    public static int c = 1;
    public static int d = -3026479;
    public final LinearLayout m_layout; //e
    public final ImageView m_image;     //f
    public final EditText m_text;   //g
    public final ImageButton m_clear_btn;  //h
    protected boolean j = true;
    private boolean k = true;
    private InputGuide m_guide = null;

    protected InputWidget(Context paramContext)
    {
        LinearLayout layout = new LinearLayout(paramContext);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.height = DrawableUtil.dp2px(a);
        layout.setLayoutParams(layoutParams);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(17);
        layout.setPadding(DrawableUtil.dp2px(10.0F), 0, DrawableUtil.dp2px(10.0F), 0);
        this.m_layout = layout;

        ImageView img = new ImageView(paramContext);
        layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.height = DrawableUtil.dp2px(b);
        layoutParams.width = DrawableUtil.dp2px(b);
        img.setLayoutParams(layoutParams);
        this.m_image = img;
        layout.addView(this.m_image);

        EditText text = new EditText(paramContext);
        layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.weight = 1.0F;
        layoutParams.height = DrawableUtil.dp2px(b);
        text.setLayoutParams(layoutParams);
        text.setPadding(DrawableUtil.dp2px(10.0F), 0, DrawableUtil.dp2px(10.0F), 0);
        CompatibleUtil.setBackgroundDrawable(text, null);
        text.setGravity(19);
        text.setTextColor(0xff000000);
        text.setHintTextColor(0xffa9a9a9);
        text.setTextSize(0, DrawableUtil.dp2px(16.0F));
        text.setSingleLine(true);
        text.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        this.m_text = text;
        layout.addView(this.m_text);


        ImageButton clearBtn = new ImageButton(paramContext);
        int pad = DrawableUtil.dp2px(10);
        layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.width = DrawableUtil.dp2px(35);
        layoutParams.height = DrawableUtil.dp2px(35);
        clearBtn.setLayoutParams(layoutParams);
        clearBtn.setPadding(pad, pad, pad, pad);
        clearBtn.setImageDrawable(DrawableUtil.getDualStateDrawable("base_login_btn_clear.png", "base_login_btn_clear_pressed.png"));
        CompatibleUtil.setBackgroundDrawable(clearBtn, null);
        clearBtn.setScaleType(ImageView.ScaleType.FIT_XY);
        this.m_clear_btn = clearBtn;

        layout.addView(this.m_clear_btn);
        this.m_clear_btn.setVisibility(View.GONE);
        this.m_clear_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                m_text.setText("");
            }
        });

        this.m_text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if ((m_guide != null) && (m_guide.onTextInput(InputWidget.this, s))) {
                    return;
                }

                j = true;
                if ((s != null) && (s.length() != 0)) {
                    m_clear_btn.setVisibility(View.VISIBLE);
                } else {
                    m_clear_btn.setVisibility(View.GONE);
                }

                String str = m_text.getText().toString();
                str = fixInput(str);
                if (s.equals(str)) {
                    return;
                }
                m_text.setText(str);
                return;
            }
        });
    }

    protected String fixInput(String input)
    {
        return input;
    }

    protected void setGuide(InputGuide guide)
    {
        this.m_guide = guide;
    }
}



/* Location:           D:\android\work\tw_sdk\classes-dex2jar.jar

 * Qualified Name:     com.ssjjsy.sdk.base.login.b

 * JD-Core Version:    0.7.0.1

 */

