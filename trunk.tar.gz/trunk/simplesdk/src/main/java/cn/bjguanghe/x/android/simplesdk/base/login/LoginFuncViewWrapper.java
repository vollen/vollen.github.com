package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;
import cn.bjguanghe.x.android.simplesdk.base.compatible.CompatibleUtil;

/**
 * Created by mob on 15/11/4.
 */
public class LoginFuncViewWrapper extends LoginViewWrapper{
    public static int LandscapeWidth = 380;
    public static int LandscapeHeight = 280;
    public static int PortraitWidth = 340;
    public static int PortraitHeight = 280;

    public static int CONTENT_ID = 100663297;

    public static int TextTitleHeight = 24;
    public static int ButtonBackSize = 20;

    public static int TopLineMargin = 3;

    public static int TopPadding = 15;
    public static int LeftPadding = 15;
    public static int RightPadding = 15;
    public static int ContentTopPadding = 15;


    public final ViewGroup container;
    public final TextView textViewTitle;
    public final ImageButton imageButtonBack;
    public final LinearLayout layoutContent;

    protected LoginFuncViewWrapper(Context hostContext) {
        super(hostContext);
        DrawableUtil.init(hostContext);

        //container
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        if(DrawableUtil.s_screenWidth > DrawableUtil.s_screenHeight) {
            LeftPadding = 25;
            RightPadding = 25;
            params.width = DrawableUtil.dp2px(LandscapeWidth);
            params.height = DrawableUtil.dp2px(LandscapeHeight);
        } else {
            params.width = DrawableUtil.dp2px(PortraitWidth);
            params.height = DrawableUtil.dp2px(PortraitHeight);
        }
        int minMargin = DrawableUtil.dp2px(10.0F);
        int maxWidth = DrawableUtil.s_screenWidth - minMargin * 2;
        int maxHeight = DrawableUtil.s_screenHeight - minMargin * 2;
        if(params.width > maxWidth) {
            params.width = maxWidth;
        }
        if(params.height > maxHeight) {
            params.height = maxHeight;
        }
        LoginFuncLayout layout = new LoginFuncLayout(hostContext);
        layout.setLayoutParams(params);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        container = layout;
        rootView.addView(container);

        //text tips
        textViewTitle = new TextView(hostContext);
        textViewTitle.setText("");
        textViewTitle.setGravity(Gravity.CENTER);
        RelativeLayout.LayoutParams tipsParams =
                new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        tipsParams.height = DrawableUtil.dp2px(TextTitleHeight);
        tipsParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        tipsParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        tipsParams.topMargin = DrawableUtil.dp2px(TopPadding + TopLineMargin);

        textViewTitle.setLayoutParams(tipsParams);
        textViewTitle.getPaint().setFakeBoldText(true);
        textViewTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, DrawableUtil.dp2px(20.0F));
        textViewTitle.setTextColor(Color.WHITE);
        container.addView(textViewTitle);

        //back button
        imageButtonBack = new ImageButton(hostContext);
        imageButtonBack.setImageDrawable(DrawableUtil.getDualStateDrawable("base_login_btn_back.png", "base_login_btn_back_pressed.png"));
        int buttonPadding = DrawableUtil.dp2px(12);
        imageButtonBack.setPadding(buttonPadding, buttonPadding, buttonPadding, buttonPadding);
        RelativeLayout.LayoutParams btnParams =
                new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        btnParams.width = DrawableUtil.dp2px(ButtonBackSize + 24); //size + 2 * padding
        btnParams.height = DrawableUtil.dp2px(ButtonBackSize + 24);
        btnParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        btnParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        btnParams.topMargin = DrawableUtil.dp2px(TopPadding - 12 + (TextTitleHeight - ButtonBackSize) / 2);//为了和title中间线在一条线上
        btnParams.leftMargin = DrawableUtil.dp2px(LeftPadding - 12);
        imageButtonBack.setLayoutParams(btnParams);
        CompatibleUtil.setBackgroundDrawable(imageButtonBack, null);
        imageButtonBack.setScaleType(ImageView.ScaleType.FIT_XY);
        container.addView(imageButtonBack);

        //content layout
        layoutContent = new LinearLayout(hostContext);
        layoutContent.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        layoutParams.topMargin = DrawableUtil.dp2px(TopPadding + TextTitleHeight + ContentTopPadding);
        layoutContent.setLayoutParams(layoutParams);
        layoutContent.setPadding(DrawableUtil.dp2px(LeftPadding), 0, DrawableUtil.dp2px(RightPadding), 0);
        layoutContent.setId(CONTENT_ID);
        container.addView(layoutContent);
    }

    protected void setTitle(String imgName) {
        Drawable titleBgDrawable = DrawableUtil.getDrawableByName(imgName);
        LinearLayout.LayoutParams params = DrawableUtil.getLinerLayoutParamsUniformScaleByHeight(titleBgDrawable, TextTitleHeight);
        textViewTitle.getLayoutParams().width = params.width;
        textViewTitle.getLayoutParams().height = params.height;
        CompatibleUtil.setBackgroundDrawable(textViewTitle, titleBgDrawable);
    }
}
