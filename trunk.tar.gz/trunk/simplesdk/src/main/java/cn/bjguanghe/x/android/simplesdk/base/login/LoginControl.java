package cn.bjguanghe.x.android.simplesdk.base.login;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import org.json.JSONObject;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;
import cn.bjguanghe.x.android.simplesdk.base.compatible.CompatibleUtil;
import cn.bjguanghe.x.android.simplesdk.base.log.LogUtil;
import cn.bjguanghe.x.android.simplesdk.base.net.DefaultParams;
import cn.bjguanghe.x.android.simplesdk.base.net.NetUtil;
import cn.bjguanghe.x.android.simplesdk.base.ui.DialogCreator;
import cn.bjguanghe.x.android.simplesdk.base.ui.DialogLayout;
import cn.bjguanghe.x.android.simplesdk.base.ui.TopLineView;

/**
 * Created by mob on 15/11/2.
 */
public class LoginControl {
    private static LoginControl _instance = null;
    private Context hostContext = null;

    private boolean isShowBack = false;

    private Dialog loginDialog = null;

    private ViewGroup contentView = null;
    private FrameLayout contentLayout = null;
    private FrameLayout loadingLayout = null;
    private FrameLayout functionLayout = null;

    private TopLineView backgroundTopLine = null;
    private GradientDrawable backgroundDrawable = null;

    private LoginLoginWrapper loginWrapper = null;
    private LoginViewWrapper currentViewWrapper = null;
    private LoginLoadingWrapper loadingWrapper = null;
    private LoginSwitchWrapper switchWrapper = null;
    private LoginAutoWrapper autoWrapper = null;

    public static LoginControl getInstance() {
        if(_instance == null) {
            _instance = new LoginControl();
        }
        return _instance;
    }

    //登录
    public void login(Context hostContext) {
        clearPreviousShow();
        //重置成员变量
        resetMember();
        //初始化
        init(hostContext);
        //显示对话框
        showDialog();

        //判断要显示哪个功能面板
        configShow();
    }

    //初始化
    private void init(Context hostContext) {
        this.hostContext = hostContext;
        //初始化显示相关和资源处理类
        DrawableUtil.init(hostContext);
        //创建窗口
        createDialog(hostContext);
        //创建内容
        createFuncLayout(hostContext);

        loginDialog.setContentView(contentView);
    }

    //创建登陆Dialog
    private void createDialog(Context hostContext) {
        loginDialog = DialogCreator.createDialog(hostContext);
        loginDialog.setCancelable(true);
        loginDialog.setCanceledOnTouchOutside(false);
        loginDialog.getWindow().setWindowAnimations(0);
    }

    //创建功能内容
    private void createFuncLayout(Context hostContext) {
        //content view
        contentView = new DialogLayout(hostContext);
        FrameLayout.LayoutParams contentParams =
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        contentView.setBackgroundColor(Color.TRANSPARENT);
        contentView.setLayoutParams(contentParams);

        //content layout
        contentLayout = new FrameLayout(hostContext);
        FrameLayout.LayoutParams contentLayoutParams =
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        contentLayoutParams.gravity = Gravity.CENTER;
        if(DrawableUtil.s_screenWidth > DrawableUtil.s_screenHeight) {
            contentLayoutParams.width = DrawableUtil.dp2px(LoginFuncViewWrapper.LandscapeWidth);
            contentLayoutParams.height = DrawableUtil.dp2px(LoginFuncViewWrapper.LandscapeHeight);
        } else {
            contentLayoutParams.width = DrawableUtil.dp2px(LoginFuncViewWrapper.PortraitWidth);
            contentLayoutParams.height = DrawableUtil.dp2px(LoginFuncViewWrapper.PortraitHeight);
        }
        contentLayout.setLayoutParams(contentLayoutParams);

        //background
        createBackground();

        //function layout
        functionLayout = new FrameLayout(hostContext);
        functionLayout.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        contentLayout.addView(functionLayout);

        //loading layout
        loadingLayout = new FrameLayout(hostContext);
        loadingLayout.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        contentLayout.addView(loadingLayout);

        //max width layout
        FrameLayout maxWidthLayout = new FrameLayout(hostContext);
        FrameLayout.LayoutParams maxWidthParams =
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        maxWidthParams.gravity = Gravity.CENTER;
        if(DrawableUtil.s_screenWidth <= DrawableUtil.s_screenHeight) {
            maxWidthParams.width = DrawableUtil.s_screenHeight;
            maxWidthParams.height = DrawableUtil.s_screenWidth;
        } else {
            maxWidthParams.width = DrawableUtil.s_screenWidth;
            maxWidthParams.height = DrawableUtil.s_screenHeight;
        }
        maxWidthLayout.setLayoutParams(maxWidthParams);
        maxWidthLayout.addView(contentLayout);
        contentView.addView(maxWidthLayout);

        //add loading content
        loadingWrapper = new LoginLoadingWrapper(hostContext);
        loadingLayout.addView(loadingWrapper.getView());
        switchWrapper = new LoginSwitchWrapper(hostContext);
        loadingLayout.addView(switchWrapper.getView());
        // TODO: 15/11/7 取消注释
        //loadingLayout.setVisibility(View.GONE);

        functionLayout.removeAllViews();
    }

    //根据逻辑显示对应的功能面板
    private void configShow() {
//        showLogin();
//        showAuto();
        RequestParams params = new DefaultParams(NetUtil.fullUrl("login"));
        params.addBodyParameter("user", "leng");
        params.addBodyParameter("password", "1234567");
        NetUtil.post(params, new Callback.CommonCallback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                LogUtil.e(result.toString());
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback) {
                LogUtil.e(ex.getMessage());
            }

            @Override
            public void onCancelled(CancelledException cex) {
                LogUtil.e(cex.getMessage());
            }

            @Override
            public void onFinished() {
                LogUtil.e("");
            }
        });
    }

    //显示登录面板
    private void showLogin() {
        //显示背景
        createBackground();

        DrawableUtil.init(hostContext);
        if(loginWrapper == null) {
            loginWrapper = new LoginLoginWrapper(hostContext);
            if(isShowBack) {
                loginWrapper.imageButtonBack.setVisibility(View.VISIBLE);
            }
        }
        switchPanel(loginWrapper);
    }

    //显示自动登陆面板
    private void showAuto() {
        //关闭背景
        hideBackground();
        showAutoPanel();
    }
    private void showAutoPanel() {
        DrawableUtil.init(hostContext);
        if(autoWrapper == null) {
            autoWrapper = new LoginAutoWrapper(hostContext);
        }
        autoWrapper.show("光核账号 ", "santianlu");
        functionLayout.removeAllViews();
        functionLayout.addView(autoWrapper.getView());
    }
    private void hideAutoPanel() {
        if(autoWrapper != null) {
            autoWrapper.hide();
        }
        if(functionLayout != null) {
            functionLayout.removeAllViews();
        }
    }







    private void switchPanel(LoginViewWrapper viewWrapper) {
        createBackground();

        //当前的View
        View view1;
        if(currentViewWrapper == null) {
            view1 = null;
        } else {
            view1 = currentViewWrapper.getView();
        }

        //新的View
        View view2;
        if(viewWrapper == null) {
            return;
        } else {
            view2 = viewWrapper.getView();
        }
        currentViewWrapper = viewWrapper;
        switchPanel(view1, view2, false);
    }

    private void switchPanel(View view1, View view2, boolean a) {
        switchPanel(view1, view2, a, true);
    }

    private void switchPanel(View view1, View view2, boolean a, boolean b) {
        if((view2 == null) && (view1 == null)) {
            return;
        }

        if((view2 != null) && (view1 == null)) {
            if(!isShowing(view2)) {
                functionLayout.addView(view2);
            }
            view2.setVisibility(View.VISIBLE);
            return;
        }

        if((view2 == null) && (view1 != null)) {
            if(!isShowing(view1)) {
                functionLayout.addView(view1);
            }
            view1.setVisibility(View.VISIBLE);
            return;
        }
    }


    private boolean isShowing(View view) {
        int childCount = functionLayout.getChildCount();
        for(int i = 0; i < childCount; i++) {
            if(view == functionLayout.getChildAt(i)) {
                return  true;
            }
        }
        return false;
    }

    //显示背景框
    private void createBackground() {
        if(backgroundTopLine == null) {
            int cornerRadius = DrawableUtil.dp2px(5.0F);

            //top line
            backgroundTopLine = new TopLineView(hostContext);
            backgroundTopLine.setRadius(cornerRadius);
            backgroundTopLine.setColor(Color.parseColor("#ff7b01"));
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.gravity = Gravity.TOP;
            params.height = (DrawableUtil.dp2px(cornerRadius)) / 3;
            backgroundTopLine.setLayoutParams(params);

            //back drawable
            backgroundDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-1, -1});
            backgroundDrawable.setCornerRadius(cornerRadius);

            contentLayout.addView(backgroundTopLine);
            backgroundTopLine.setVisibility(View.GONE);
        }

        if(backgroundTopLine.getVisibility() != View.VISIBLE) {
            backgroundTopLine.setVisibility(View.VISIBLE);
            CompatibleUtil.setBackgroundDrawable(contentLayout, backgroundDrawable);
        }
    }

    //隐藏背景框
    private void hideBackground() {
        if(this.backgroundTopLine != null && this.backgroundTopLine.getVisibility() != View.GONE) {
            this.backgroundTopLine.setVisibility(View.GONE);
            CompatibleUtil.setBackgroundDrawable(contentLayout, backgroundDrawable);
        }
    }

    //显示登录Dialog
    private void showDialog() {
        if(this.loginDialog != null) {
            this.loginDialog.show();
        }
    }

    //清理上一次的显示(如果有)
    private void clearPreviousShow() {
        clearFuncLayout();
        if(loginDialog != null && loginDialog.isShowing()) {
            loginDialog.dismiss();
        }
        loginDialog = null;
    }

    //清理登陆功能的显示root层
    private void clearFuncLayout() {
        if(functionLayout != null) {
            functionLayout.removeAllViews();
        }
    }

    //重置成员变量
    private void resetMember() {
        if(functionLayout != null) {
            functionLayout.removeAllViews();
        }
        contentLayout = null;
        contentView = null;
        loadingLayout = null;
        functionLayout = null;
        backgroundTopLine = null;
        backgroundDrawable = null;

        loginWrapper = null;
        switchWrapper = null;
        currentViewWrapper = null;
        loadingWrapper = null;
        autoWrapper = null;
    }

    //登陆模块网络代理
    static class NetAgent{
        public void register(){

        }

        public void login(){

        }
    }
}
