package cn.bjguanghe.x.android.simplesdk.base.ui;

import android.content.Context;
import android.widget.FrameLayout;

/**
 * Created by mob on 15/11/2.
 */
public class DialogLayout extends FrameLayout {

    public DialogLayout(Context hostContext) {
        super(hostContext);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
    }
}
