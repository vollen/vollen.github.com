package cn.bjguanghe.x.android.simplesdk.base.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import cn.bjguanghe.x.android.simplesdk.exception.NetInvalidException;

/**
 * Created by leng on 16-1-5.
 */
public class NetUtil {
    private static final String TAG = "net";
    private static final String BASE_URL = "https://api.bjguanghe.cn/api/user";
    private static Context sCtx = null;

    public static void init(Context ctx){
        sCtx = ctx;
    }

    public static String fullUrl(String path){
        return  BASE_URL + "/" + path;
    }

    public static <T> void get(RequestParams params, Callback.CommonCallback<T> callBack){
        if (!isNetAvailable()) {
            callBack.onError(new NetInvalidException(), false);
            return;
        }

        x.http().get(params, callBack);
        return;
    }

    public static <T> void post(RequestParams params, Callback.CommonCallback<T> callBack){
        if (!isNetAvailable()) {
            callBack.onError(new NetInvalidException(), false);
            return ;
        }

        x.http().post(params, callBack);
        return;
    }

    //SYNC 方法只能在非同步线程中使用
    public static <T> T getSync(RequestParams params, Class<T> resultType) throws Throwable{
        if (!isNetAvailable()) {
            throw new NetInvalidException();
        }
        return x.http().getSync(params, resultType);
    }

    //发送数据
    public static <T> T postSync(RequestParams params, Class<T> resultType) throws Throwable {
        if (!isNetAvailable()) {
            throw new NetInvalidException();
        }
        return x.http().postSync(params, resultType);
    }


    public static boolean isNetAvailable()
    {
        ConnectivityManager localConnectivityManager = (ConnectivityManager)sCtx.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
        if (localNetworkInfo != null) {
            return localNetworkInfo.isAvailable();
        }
        return false;
    }

}
