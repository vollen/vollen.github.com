package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;
import cn.bjguanghe.x.android.simplesdk.base.compatible.CompatibleUtil;

/**
 * Created by mob on 15/11/9.
 */
public class LoginAutoWrapper extends LoginViewWrapper {

    private final ViewGroup contentView;
    private final TextView textViewTitle;
    private final View viewCircle;
    private final View viewSwitch;


    public LoginAutoWrapper(Context hostContext) {
        super(hostContext);

        FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        int paddingX = DrawableUtil.dp2px(20.0F);
        int paddingY = DrawableUtil.dp2px(20.0F);
        rootView.setLayoutParams(params);
        rootView.setPadding(paddingX, paddingY, paddingX, paddingY);

        //content view
        LinearLayout content = new LinearLayout(hostContext);
        LinearLayout.LayoutParams contentParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        contentParams.width = DrawableUtil.dp2px(280.0F);
        contentParams.height = DrawableUtil.dp2px(120.0F);
        GradientDrawable contentBg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{ -1895825408, -1895825408});
        contentBg.setCornerRadius(DrawableUtil.dp2px(5.0F));
        CompatibleUtil.setBackgroundDrawable(content, contentBg);
        content.setGravity(Gravity.CENTER);
        content.setOrientation(LinearLayout.VERTICAL);
        rootView.addView(content);
        contentView = content;

        //text view
        textViewTitle = createTextView(16, Color.WHITE);
        LinearLayout.LayoutParams textParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textParams.leftMargin = DrawableUtil.dp2px(10.0F);
        textParams.rightMargin = DrawableUtil.dp2px(10.0F);
        textViewTitle.setLayoutParams(textParams);
        contentView.addView(textViewTitle);

        //loading circle
        LinearLayout subContainer = new LinearLayout(hostContext);
        LinearLayout.LayoutParams baseParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        baseParams.topMargin = DrawableUtil.dp2px(3.0F);
        subContainer.setLayoutParams(baseParams);
        subContainer.setOrientation(LinearLayout.HORIZONTAL);
        subContainer.setGravity(Gravity.CENTER);
        contentView.addView(subContainer);
        TextView textTips = createTextView(16, Color.WHITE);
        textTips.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        textTips.setText("正在登录 ");
        subContainer.addView(textTips);
        viewCircle = new View(hostContext);
        LinearLayout.LayoutParams circleParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        circleParams.width = DrawableUtil.dp2px(16.0F);
        circleParams.height = DrawableUtil.dp2px(16.0F);
        viewCircle.setLayoutParams(circleParams);
        CompatibleUtil.setBackgroundDrawable(viewCircle, DrawableUtil.getDrawableByName("base_login_loading_circle.png"));
        subContainer.addView(viewCircle);

        //switch view
        viewSwitch = createSwitch(hostContext, new int[]{-34816, -1676288});
        LinearLayout.LayoutParams paramsSwitch =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        paramsSwitch.topMargin = DrawableUtil.dp2px(10.0F);
        viewSwitch.setLayoutParams(paramsSwitch);
        contentView.addView(viewSwitch);

        rootView.setVisibility(View.GONE);
    }

    public void hide() {
        rootView.setVisibility(View.GONE);
        viewCircle.clearAnimation();
    }

    public void show(String userType, String account) {
        setTitle(userType, account, "");
        if(rootView.getVisibility() != View.VISIBLE) {
            RotateAnimation animation = new RotateAnimation(0.0F, 360.0F, 1, 0.5F, 1, 0.5F);
            animation.setRepeatCount(RotateAnimation.INFINITE);
            animation.setDuration(1000L);
            animation.setInterpolator(new LinearInterpolator());
            viewCircle.clearAnimation();
            viewCircle.startAnimation(animation);
            rootView.setVisibility(View.VISIBLE);
        }
    }

    protected void setTitle(String userType, String account, String param) {
        if((account == null) || (account.length() == 0)) {
            textViewTitle.setText(userType + param);
            return;
        }

        SpannableStringBuilder builder = new SpannableStringBuilder();
        builder.append(userType);
        builder.append(account);
        builder.setSpan(new ForegroundColorSpan(-34816), userType.length(), builder.length(), 17);
        builder.setSpan(new StyleSpan(1), userType.length(), builder.length(), 17);
        builder.append(param);
        textViewTitle.setText(builder);
    }


    private View createSwitch(Context hostContext, int[] colorGradient) {
        LinearLayout linearLayout = new LinearLayout(hostContext);
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        linearLayout.setPadding(DrawableUtil.dp2px(10.0F), DrawableUtil.dp2px(5.0F), DrawableUtil.dp2px(10.0F), DrawableUtil.dp2px(5.0F));
        linearLayout.setLayoutParams(params);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);

        GradientDrawable bg1 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{colorGradient[0], colorGradient[0]});
        GradientDrawable bg2 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{colorGradient[1], colorGradient[1]});
        bg1.setCornerRadius(DrawableUtil.dp2px(3.0F));
        bg2.setCornerRadius(DrawableUtil.dp2px(3.0F));

        CompatibleUtil.setBackgroundDrawable(linearLayout, DrawableUtil.getDualStateDrawable(bg1, bg2));
        linearLayout.setGravity(Gravity.CENTER);

        Drawable drawableSwitch = DrawableUtil.getDrawableByName("base_login_btn_icon_switch.png");
        ImageView imageViewSwitch = new ImageView(hostContext);
        imageViewSwitch.setLayoutParams(DrawableUtil.getLinerLayoutParamsUniformScaleByHeight(drawableSwitch, 16.0F));
        imageViewSwitch.setScaleType(ImageView.ScaleType.FIT_XY);
        CompatibleUtil.setBackgroundDrawable(imageViewSwitch, drawableSwitch);
        linearLayout.addView(imageViewSwitch);

        TextView textSwitch = new TextView(hostContext);
        LinearLayout.LayoutParams textParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textParams.weight = 1.0F;
        textParams.leftMargin = DrawableUtil.dp2px(10.0F);
        textSwitch.setLayoutParams(textParams);
        textSwitch.setTextSize(0, DrawableUtil.dp2px(16.0F));
        textSwitch.setTextColor(Color.WHITE);
        textSwitch.setText("切换账号");
        linearLayout.addView(textSwitch);

        return  linearLayout;
    }
}
