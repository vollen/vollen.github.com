package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;

/**
 * Created by mob on 15/11/4.
 */
public class LoginViewWrapper {
    protected Context hostContext;
    public final FrameLayout rootView;

    public LoginViewWrapper(Context hostContext) {
        this.hostContext = hostContext;
        this.rootView = new FrameLayout(this.hostContext);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        this.rootView.setLayoutParams(params);
        this.rootView.setTag(this);
    }

    public ViewGroup getView() {
        return this.rootView;
    }

    //创建一个TextView
    protected TextView createTextView(int fontSize, int color) {
        TextView textView = new TextView(hostContext);
        textView.setTextSize(0, DrawableUtil.dp2px(fontSize));
        textView.setTextColor(color);
        return textView;
    }

    //创建一个button
    protected Button createButton(int fontSize, int fontColor) {
        Button button = new Button(hostContext);
        button.setPadding(0, 0, 0, 0);
        button.setTextSize(DrawableUtil.dp2px(fontSize));
        button.setTextColor(fontColor);
        return button;
    }
}
