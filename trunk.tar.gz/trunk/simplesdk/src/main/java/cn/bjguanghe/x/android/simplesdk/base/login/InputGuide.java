package cn.bjguanghe.x.android.simplesdk.base.login;

/**
 * Created by leng on 16-1-9.
 */
public interface InputGuide {
    public abstract boolean onTextInput(InputWidget input, CharSequence s);
}
