package cn.bjguanghe.x.android.simplesdk.base.misc;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

import cn.bjguanghe.x.android.simplesdk.base.util.DrawableUtil;

/**
 * Created by mob on 15/11/7.
 */
public class GradientDrawableCreator {

    public static Drawable getDualStateDrawable(int color1, int color2, int color3) {
        return DrawableUtil.getDualStateDrawable(getDrawable(color1, color3), getDrawable(color2, color3));
    }

    public static GradientDrawable getDrawable(int color1, int color2) {
        GradientDrawable drawable =
                new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{color1, color2});
        return drawable;
    }
}
