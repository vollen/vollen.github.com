package cn.bjguanghe.x.android.simplesdk.base.ui;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/**
 * Created by mob on 15/11/2.
 */
public class DialogCreator {

    public static Dialog createDialog(Context hostContext) {
        Dialog resultDialog = new Dialog(hostContext);
        resultDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = resultDialog.getWindow();
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        WindowManager.LayoutParams params = window.getAttributes();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.gravity = Gravity.CENTER;
        params.horizontalMargin = 0.0F;
        params.verticalMargin = 0.0F;
        params.horizontalWeight = 0.0F;
        params.verticalWeight = 0.0F;
        params.alpha = 1.0F;
        window.setAttributes(params);
        window.setBackgroundDrawable(null);
        resultDialog.onWindowAttributesChanged(params);
        resultDialog.setCanceledOnTouchOutside(true);

        View decorView = window.getDecorView();
        decorView.setBackgroundColor(0);
        decorView.setPadding(0, 0, 0, 0);

        return resultDialog;
    }
}

