package cn.bjguanghe.x.android.simplesdk.base.log;

import android.util.Log;
import android.widget.Toast;

import org.xutils.x;

/**
 * Created by leng on 16-1-7.
 */
public class LogUtil {
    private static final boolean sIsDebug = true;
    private static final boolean sShowTip = true;
    private static final String sPrefix = "gh_log";

    private static String generateTag() {
        StackTraceElement caller = new Throwable().getStackTrace()[2];
        String tag = "%s.%s(L:%d)";
        String callerClazzName = caller.getClassName();
        callerClazzName = callerClazzName.substring(callerClazzName.lastIndexOf(".") + 1);
        tag = String.format(tag, callerClazzName, caller.getMethodName(), caller.getLineNumber());
        tag = sPrefix + ":" + tag;
        return tag;
    }

    public static void toast(String content){
        if (!sShowTip) return;
        Toast.makeText(x.app(), content, 0).show();
    }

    public static void fTotast(String content){
        Toast.makeText(x.app(), content,  0).show();
    }

    //自定义的log函数
    public static void s(String content){
        if (!sIsDebug) return;
        Log.e(generateTag(), content);
    }

    public static void d(String content) {
        if (!sIsDebug) return;
        Log.d(generateTag(), content);
    }

    public static void d(String content, Throwable tr) {
        if (!sIsDebug) return;
        Log.d(generateTag(), content, tr);
    }

    public static void e(String content) {
        if (!sIsDebug) return;
        Log.e(generateTag(), content);
    }

    public static void e(String content, Throwable tr) {
        if (!sIsDebug) return;
        Log.e(generateTag(), content, tr);
    }

    public static void i(String content) {
        if (!sIsDebug) return;
        Log.i(generateTag(), content);
    }

    public static void i(String content, Throwable tr) {
        if (!sIsDebug) return;
        Log.i(generateTag(), content, tr);
    }

    public static void v(String content) {
        if (!sIsDebug) return;
        Log.v(generateTag(), content);
    }

    public static void v(String content, Throwable tr) {
        if (!sIsDebug) return;
        Log.v(generateTag(), content, tr);
    }

    public static void w(String content) {
        if (!sIsDebug) return;
        Log.w(generateTag(), content);
    }

    public static void w(String content, Throwable tr) {
        if (!sIsDebug) return;
        Log.w(generateTag(), content, tr);
    }

    public static void w(Throwable tr) {
        if (!sIsDebug) return;
        Log.w(generateTag(), tr);
    }


    public static void wtf(String content) {
        if (!sIsDebug) return;
        Log.wtf(generateTag(), content);
    }

    public static void wtf(String content, Throwable tr) {
        if (!sIsDebug) return;
        Log.wtf(generateTag(), content, tr);
    }

    public static void wtf(Throwable tr) {
        if (!sIsDebug) return;
        Log.wtf(generateTag(), tr);
    }

}
