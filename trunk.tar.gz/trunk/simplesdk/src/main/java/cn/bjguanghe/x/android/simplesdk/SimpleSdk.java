package cn.bjguanghe.x.android.simplesdk;

import android.app.Activity;
import android.content.Context;

import org.xutils.x;

import cn.bjguanghe.x.android.simplesdk.base.log.LogUtil;
import cn.bjguanghe.x.android.simplesdk.base.login.LoginControl;
import cn.bjguanghe.x.android.simplesdk.base.net.NetUtil;
import cn.bjguanghe.x.android.simplesdk.net.SimpleSdkDialogListener;

/**
 * Created by jingkun on 15-10-28.
 */
public class SimpleSdk {
    private static SimpleSdk _Instance = null;

    private static String _ClientId = null;
    private static String _ClientKey = null;

    private SimpleSdkDialogListener mSimpleSdkDialogListener = null;
    private Context hostContext = null;
    private Activity hostActivity = null;

    public SimpleSdk() {
        _Instance = this;
    }

    //初始化
    public static void init(String clientId, String clientKey) {
        _ClientId = clientId;
        _ClientKey = clientKey;
        LogUtil.i("clientid:" + clientId + " clientkey:" + clientKey);
    }

    //授权登陆
    public void authorize(Context hostContext) {
        setParam((Activity) hostContext, hostContext);

        this.hostContext = hostContext;
        x.Ext.init(hostContext);
        x.Ext.setDebug(true);
        NetUtil.init(hostContext);
        LoginControl loginControl = LoginControl.getInstance();
        loginControl.login(hostContext);
    }

    private void setParam(Activity hostActivity, Context hostContext) {
        this.hostActivity = hostActivity;
        this.hostContext = hostContext;
    }
}
