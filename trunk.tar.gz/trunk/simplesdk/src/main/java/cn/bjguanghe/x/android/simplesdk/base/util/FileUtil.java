package cn.bjguanghe.x.android.simplesdk.base.util;

import android.content.Context;

import java.io.File;
/**
 * Created by leng on 16-1-5.
 */
public class FileUtil{
    public static void deleteFile(File file){
        if (file.isFile()) {
            file.delete();
        }
        while (!file.isDirectory()) {
            return;
        }
        File[] arrayOfFile = file.listFiles();
        if ((arrayOfFile == null) || (arrayOfFile.length == 0))
        {
            file.delete();
            return;
        }

        for (File _file : arrayOfFile){
            deleteFile(_file);
        }

        file.delete();
    }

    public static File getFile(Context ctx, String name){
        return  new File(fullPathForName(ctx, name));
    }

    public static String fullPathForName(Context ctx, String name)
    {
        return ctx.getFilesDir() + "/" + name;
    }
}