package cn.bjguanghe.x.android.simplesdk.base.login;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.RelativeLayout;

/**
 * Created by mob on 15/11/4.
 */
public class LoginFuncLayout extends RelativeLayout{

    public LoginFuncLayout(Context hostContext) {
        super(hostContext);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return super.onTouchEvent(ev);
    }
}
