package cn.bjguanghe.x.android.simplesdksample;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by mob on 15/11/1.
 */
public class MyDialogFragment extends DialogFragment {

    int mNum;

    public static MyDialogFragment newInstance(int num) {
        MyDialogFragment f = new MyDialogFragment();

        //提供参数
        Bundle args = new Bundle();
        args.putInt("num", num);
        f.setArguments(args);

        return  f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mNum = getArguments().getInt("num");

        int style = DialogFragment.STYLE_NORMAL, theme = 0;
        switch ((mNum - 1) % 6) {
            case 1: style = DialogFragment.STYLE_NO_TITLE; break;
            case 2: style = DialogFragment.STYLE_NO_FRAME; break;
            case 3: style = DialogFragment.STYLE_NO_INPUT; break;
            case 4: style = DialogFragment.STYLE_NORMAL; break;
            case 5: style = DialogFragment.STYLE_NORMAL; break;
            case 6: style = DialogFragment.STYLE_NO_TITLE; break;
            case 7: style = DialogFragment.STYLE_NO_FRAME; break;
            case 8: style = DialogFragment.STYLE_NORMAL; break;
        }

        switch ((mNum - 1) % 6) {
            case 4: theme = android.R.style.Theme_Material; break;
            case 5: theme = android.R.style.Theme_Material_Light_Dialog; break;
            case 6: theme = android.R.style.Theme_Material_Light; break;
            case 7: theme = android.R.style.Theme_Material_Light_Panel; break;
            case 8: theme = android.R.style.Theme_Material_Light;
        }

        setStyle(style, theme);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog, container, false);

        TextView textView = (TextView)view.findViewById(R.id.text_fragment_dialog_test1);
        textView.setText("Dialog #" + mNum + ": using style " + String.valueOf(mNum));

        Button button = (Button)view.findViewById(R.id.button_fragment_dialog_test2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).showDialog();
            }
        });
        return  view;
    }
}
