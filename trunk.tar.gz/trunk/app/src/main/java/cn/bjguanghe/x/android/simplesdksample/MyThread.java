package cn.bjguanghe.x.android.simplesdksample;

import cn.bjguanghe.x.android.simplesdk.base.log.LogUtil;

/**
 * Created by mob on 15/11/5.
 */
public class MyThread extends Thread  {
    private int a = 0;
    private String b = "";

    public MyThread(int aa, String bb) {
        a = aa;
        b = bb;
    }

    @Override
    public void run() {
        super.run();
        LogUtil.e(b);
        LogUtil.e(String.valueOf(a));
    }
}
