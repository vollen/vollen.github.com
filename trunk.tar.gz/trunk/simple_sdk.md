
# Base_Url
http://api.bjguanghe.cn/api/user

+ 登陆
http://api.bjguanghe.cn/api/user/login


# register
## url
http://api.bjguanghe.cn/api/user/register

## 前端发送字段
+ user
+ password

## 后端返回
