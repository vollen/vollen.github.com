package cn.bjguanghe.x.android.simplesdk.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;
import dalvik.system.DexClassLoader;

/**
 * Created by mob on 15/11/10.
 */
public class SimpleSdkUtil {

    protected static DexClassLoader getBaseDexClassLoader(Context hostContext, SimpleSdkBaseInfo info) {
        // TODO: 15/11/10 实现解压文件 然后加载类
        return null;
    }

    protected static String getFilesDir(Context hostContext, String subDir) {
        return hostContext.getFilesDir() + "/" + subDir;
    }

    protected static String getFilesDirJarFile(Context hostContext, String jarName) {
        return hostContext.getFilesDir() + "/" + jarName + "/" + jarName + ".jar";
    }

    protected static boolean checkNetwork(Context hostContext) {
        NetworkInfo networkInfo =
                ((ConnectivityManager)hostContext.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if(networkInfo != null && networkInfo.isConnectedOrConnecting()) {
            String netExtraInfo = networkInfo.getExtraInfo();
            if(netExtraInfo != null && netExtraInfo.toLowerCase().contains("wap")) {
                Toast.makeText(hostContext, "当前使用的网络是wap模式，如果更好为wifi网络，玩游戏会更流畅哦！", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        Toast.makeText(hostContext, "您的网络连接已中断", Toast.LENGTH_LONG).show();
        return false;
    }
}
