package cn.bjguanghe.x.android.simplesdk.net;

import android.os.Bundle;

/**
 * Created by mob on 15/11/10.
 */
public interface SimpleSdkDialogListener {
    void onComplete(Bundle params);
    void onSimpleSdkException(SimpleSdkException exception);
    void onError(DialogError error);
    void onCancel();
}
