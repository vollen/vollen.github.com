package cn.bjguanghe.x.android.simplesdk.net;

/**
 * Created by mob on 15/11/10.
 */
public class SimpleSdkException extends Exception {
    private int mStatusCode = -1;

    public SimpleSdkException() {

    }

    public SimpleSdkException(String detailMessage) {
        super(detailMessage);
    }

    public SimpleSdkException(Exception throwable) {
        super(throwable);
    }

    public SimpleSdkException(String detailMessage, int statusCode) {
        super(detailMessage);
        this.mStatusCode = statusCode;
    }

    public SimpleSdkException(String detailMessage, Exception throwable) {
        super(detailMessage, throwable);
    }

    public SimpleSdkException(String detailMessage, Exception throwable, int statusCode) {
        super(detailMessage, throwable);
        this.mStatusCode = statusCode;
    }

    public SimpleSdkException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public SimpleSdkException(Throwable throwable) {
        super(throwable);
    }

    public SimpleSdkException(int statusCode) {
        mStatusCode = statusCode;
    }

    public void setStatusCode(int statusCode) {
        mStatusCode = statusCode;
    }

    public int getStatusCode() {
        return mStatusCode;
    }


}
