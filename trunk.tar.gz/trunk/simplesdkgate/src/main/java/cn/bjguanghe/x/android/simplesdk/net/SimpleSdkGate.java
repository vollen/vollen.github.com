package cn.bjguanghe.x.android.simplesdk.net;

import android.app.Activity;
import android.content.Context;

import java.lang.reflect.Method;

/**
 * Created by mob on 15/11/10.
 */
public class SimpleSdkGate {

    private static SimpleSdkGate _Instance = null;
    private static Context HostContext;
    private static ClassLoader BaseClassLoader = null;//m
    private static Class BaseClass;//e
    private static Object BaseClassInstance;//i

    public static void init(Context hostContext) {
        initUncaughtExceptionHandler(hostContext);
        HostContext = hostContext;

        initBase(hostContext);
    }

    public static synchronized SimpleSdkGate getInstance() {
        if(_Instance == null) {
            _Instance = new SimpleSdkGate();
        }
        return _Instance;
    }

    public static void initUncaughtExceptionHandler(Context hostContext) {
        Thread.setDefaultUncaughtExceptionHandler(SimpleSdkUncaughtExceptionHandler.getExceptionHandler(hostContext));
    }

    protected static void reportFrontError(Context hostContext, String errMsg) {

    }

    private static void initBase(Context hostContext) {
        SimpleSdkBaseInfo baseInfo = new SimpleSdkBaseInfo();
        baseInfo.setBaseDir(SimpleSdkUtil.getFilesDir(hostContext, "base"));
        baseInfo.setBaseDexFile(SimpleSdkUtil.getFilesDirJarFile(hostContext, "base"));
        baseInfo.setBaseZipFile("base.zip");
        baseInfo.setBaseClassName("cn.bjguanghe.x.android.simplesdk.SimpleSdk");

        Object loader = SimpleSdkUtil.getBaseDexClassLoader(hostContext, baseInfo);
        if(loader == null) {
            loader = hostContext.getClassLoader();
        }

        try {
            BaseClassLoader = (ClassLoader)loader;
            BaseClass = BaseClassLoader.loadClass(baseInfo.getBaseClassName());
            BaseClassInstance = BaseClass.newInstance();
            if(BaseClassInstance != null) {
                Method initMethod = BaseClass.getMethod("init", String.class, String.class);
                initMethod.invoke(BaseClassInstance, "123", "client_key");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //授权登陆
    public void authorize(Activity hostActivity) {
        //检测当前网络
        if(!SimpleSdkUtil.checkNetwork(hostActivity)) {
            return;
        }

        try {
            Method authorizeMethod = BaseClass.getMethod("authorize", Context.class);
            authorizeMethod.invoke(BaseClassInstance, hostActivity);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
