package cn.bjguanghe.x.android.simplesdk.net;

/**
 * Created by mob on 15/11/10.
 */
public class SimpleSdkBaseInfo {
    private String mBaseDir;//a
    private String mBaseDexFile;//b
    private String mBaseZipFile;//c
    private String mBaseClassName;//d

    protected String getBaseDir() {
        return mBaseDir;
    }

    protected String getBaseDexFile() {
        return mBaseDexFile;
    }

    protected String getBaseZipFile() {
        return mBaseZipFile;
    }

    protected String getBaseClassName() {
        return mBaseClassName;
    }

    protected void setBaseDir(String baseDir) {
        this.mBaseDir = baseDir;
    }

    protected void setBaseDexFile(String baseDexFile) {
        this.mBaseDexFile = baseDexFile;
    }

    protected void setBaseZipFile(String baseZipFile) {
        this.mBaseZipFile = baseZipFile;
    }

    protected void setBaseClassName(String baseClassName) {
        this.mBaseClassName = baseClassName;
    }
}
