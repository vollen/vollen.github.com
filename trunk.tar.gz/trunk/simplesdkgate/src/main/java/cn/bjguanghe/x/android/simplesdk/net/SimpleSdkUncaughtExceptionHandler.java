package cn.bjguanghe.x.android.simplesdk.net;

import android.content.Context;

/**
 * Created by mob on 15/11/10.
 */
public class SimpleSdkUncaughtExceptionHandler extends Exception implements Thread.UncaughtExceptionHandler{
    private Thread.UncaughtExceptionHandler defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
    private static Context _HostContext;

    public static SimpleSdkUncaughtExceptionHandler getExceptionHandler(Context hostContext) {
        _HostContext = hostContext;
        return new SimpleSdkUncaughtExceptionHandler();
    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        report(ex);
        if(defaultHandler != null) {
            defaultHandler.uncaughtException(thread, ex);
        }
    }

    //上报错误信息
    private void report(Throwable throwable) {
        if(throwable == null) {
            return;
        }
        String detailMsg = getStackTraceMessage(throwable);
        SimpleSdkGate.reportFrontError(_HostContext, detailMsg);
    }

    //获取所有的堆栈错误信息
    private String getStackTraceMessage(Throwable throwable) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(throwable.getMessage() + "\n");
        StackTraceElement[] stackTrace = throwable.getStackTrace();
        for(int i = 0; i < stackTrace.length; i++) {
            stringBuffer.append(stackTrace[i].toString() + "\n");
        }
        return stringBuffer.toString();
    }
}
