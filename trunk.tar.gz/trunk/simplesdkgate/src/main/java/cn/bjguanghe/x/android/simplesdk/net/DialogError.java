package cn.bjguanghe.x.android.simplesdk.net;

/**
 * Created by mob on 15/11/10.
 */
public class DialogError extends Throwable {
    private int code;
    private String content;

    public DialogError(String detailMessage, int code, String content) {
        super(detailMessage);
        this.code = code;
        this.content = content;
    }
}
